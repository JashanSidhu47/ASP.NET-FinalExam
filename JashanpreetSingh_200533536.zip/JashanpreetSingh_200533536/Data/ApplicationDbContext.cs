﻿using Microsoft.EntityFrameworkCore;
using JashanpreetSingh_200533536.Models;
using System.Collections.Generic;


namespace JashanpreetSingh_200533536.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Car> Cars { get; set; } // Add this DbSet for the Car model

        // ... other DbSet configurations or model configurations ...
    }
}
